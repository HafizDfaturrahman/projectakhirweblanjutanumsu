# Laundry Crafty
Laundry Crafty merupakan sebuah sistem informasi sederhana berbasis web.<br />
Laundry Crafty juga merupakan contoh aplikasi web CRUD sederhana dengan PHP dan MySQL.<br />
Laundry Crafty digunakan untuk melakukan pendataan terhadap laundry masuk dan laundry keluar. Laundry Crafty dibangun menggunakan PHP, Bootstrap, dan MySQL.

# Demo
Username	: admin<br />
Password	: admin<br />
URL Web		: https://laundrycrafty.azurewebsites.net
