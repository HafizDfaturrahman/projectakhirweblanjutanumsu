<?php
    $hostname  = "localhost";
    $username  = "root";
    $password  = "";
    $dbname  = "crud_laundry";
    $conn = mysqli_connect($hostname, $username, $password, $dbname);    
?>