<div id="sidebar-wrapper">
    <ul class="sidebar-nav">
        <li>
            <a href="../index.php"><span class="glyphicon glyphicon-dashboard"></span> Dashboard</a>
        </li>
        <li>
            <a href="../laundry-masuk"><span class="glyphicon glyphicon-list-alt"></span> Laundry Masuk</a>
        </li>
        <li>
            <a href="../laundry-keluar"><span class="glyphicon glyphicon-shopping-cart"></span> Laundry Keluar</a>
        </li>        
        <li>
            <a href="../tentang"><span class="glyphicon glyphicon-th"></span> Tentang Laundry laugh tale</a>
        </li>
    </ul>
</div>