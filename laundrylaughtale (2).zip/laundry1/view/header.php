<!doctype html>
    <html lang="en">
    <head>        
        <title>Laundry laugh tale</title>
	    <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="../css/bootstrap.min.css">
        <link rel="stylesheet" href="../css/main.css">
        <link rel="stylesheet" href="../css/sidebar.css">        
    </head>
    <body>
        <?php include('navbar.php'); ?>
        <div id="wrapper">            
            <?php include('sidebar.php'); ?>